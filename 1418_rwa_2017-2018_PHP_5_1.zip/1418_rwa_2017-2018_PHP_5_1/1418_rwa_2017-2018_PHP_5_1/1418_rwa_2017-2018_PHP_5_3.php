<html>
<head></head>
<body>

<form action="" method="get">
		Unesite broj:<input name="broj" type="number" >
		<input type="submit" value="Izračunaj">
</form>
		
<?php
function fact($n) {
  if ($n==0) {
    return 1;
  }
  return $n*fact($n-1);
 }

if(isset($_GET["broj"])){
	$x=$_GET["broj"];
for ($i=1; $i<=$x; $i++){
	echo $i . "!=" . fact($i) . "<br>";
	}
}
?>


</body>
</html>